import mysql.connector as con
import pandas as pd
db=con.connect(user="root",password='root',host="localhost",port=3309) 
mycursor=db.cursor()
mycursor.execute("create database if not exists Pharmacy")
mycursor.execute("use Pharmacy;")
mycursor.execute("commit;")

def Menu():
    print("              Welcome to Uphar Pharmacy                        ")
    print('')
    print("Enter 1: To Add a Product")
    print("Enter 2: To Delete a Product")
    print("Enter 3: To View all Products")
    print("Enter 4: To Generate a bill")
    print("Enter 5: To display analytical graphs")
    print('')
    user_choice=int(input("Enter your choice(1-5):"))
    print('')
    if user_choice==1:
        addProd()
    elif user_choice==2:
        delProd()
    elif user_choice==3:
        viewProd()
    elif user_choice==4:
        bill()
    elif user_choice==5:
        graph()
    else:
        print("Enter valid choice")

def  addProd():
    try:
        p_id=int(input("Enter id of product to be added:"))
        name=input("Enter name of product to be added:")
        pr=int(input("Enter price of product to be added:"))
        st=int(input("Enter stock of product to be added:"))
        ct=input("Enter category of product to be added:")
        db=con.connect(user="root",password='root',host="localhost",port=3309)
        mycursor=db.cursor()
        mycursor.execute("use Pharmacy;")
        query="insert into list_meds(Id,MedName,Price,Stock,Category)VALUES(%s,%s,%s,%s,%s)"
        details=(p_id,name,pr,st,ct)
        mycursor.execute(query,details)
        mycursor.execute("commit;")
        print('')
        print("Record added successfully")
        print('')
    except Exception:
        print('')
        print("Error! Please check inputted details")
        print('')


def  delProd():
        name=input("Enter name of product to be deleted:")
        name=name.lower()
        db=con.connect(user="root",password='root',host="localhost",port=3309)
        mycursor=db.cursor()
        mycursor.execute("use Pharmacy;")
        mycursor.execute("delete from list_meds where lower(MedName)='"+name+"'")
        mycursor.execute("commit;")
        print('')
        print("Record deleted successfully")
        print('')

def  viewProd():
    db=con.connect(user="root",password='root',host="localhost",port=3309)
    mycursor=db.cursor()
    mycursor.execute("use Pharmacy;")
    mycursor.execute("select * from list_meds;")
    data=mycursor.fetchall()    
    final=pd.DataFrame(data,columns=['ID','MedName','Price','Stock','Category'])
    print(final)
    print('')
    
def bill():
    name=input("Enter your name:")
    date=input("Enter today's date in (dd/mm/yy):")
    print('')
    print("Enter 1: To Buy one Medicine")
    print("Enter 2: To Multiple Medicines")
    cho=int(input("Enter (1-2):"))
    print('')
    if cho==1:
        med=input("Enter name of the medicine to be bought:")
        qty=int(input("Enter quantity of medicine to be bought:"))
        db=con.connect(user="root",password='root',host="localhost",port=3309)
        mycursor=db.cursor()
        mycursor.execute("use Pharmacy;")
        mycursor.execute("select Price from list_meds where MedName='"+med+"';")
        for data in mycursor:
            a=data
            price=0
            price=int(a[0])*qty
        tot=price
        df=pd.DataFrame({'Medines':[med],'Quantity':[qty],'Price':[price]},index=[1])
        df.to_csv("C:/Users/student.JPHS/Desktop/Project folder/bill.csv")
    elif cho==2:
        ch=int(input("Enter number of medicines to be bought:"))
        i=ch
        list1=[]
        list2=[]
        list3=[]
        while i>0:
            med=input("Enter name of the medicine to be bought:")
            qty=int(input("Enter quantity of medicine to be bought:"))
            list1.append(med)
            list2.append(qty)
            db=con.connect(user="root",password='root',host="localhost",port=3309)
            mycursor=db.cursor()
            mycursor.execute("use Pharmacy;")
            mycursor.execute("select Price from list_meds where MedName='"+med+"';")
            for data in mycursor:
                a=data
                price=int(a[0])*qty
                list3.append(price)     
            i=i-1
        tot=sum(list3)
        df=pd.DataFrame({'Medicines':list1,'Quantity':list2,'Price':list3})
        df.index=range(1,len(list1)+1)
        df.to_csv("C:/Users/student.JPHS/Desktop/Project folder/bill.csv")
    else:
        print("Enter valid data")
    print('')
    print('            BILL        ')
    print('****************************')
    print("Customer Name:",name)
    print("Date of Purchase:",date)
    print('')
    print("List of medicines purchased:\n",df)
    print("Your total is:",tot)
    print('')
    print("Your bill has been saved in an csv file called 'bill' ")
    print('')

def graph():
    l1=[]
    l2=[]
    db=con.connect(user="root",password='root',host="localhost",port=3309)
    mycursor=db.cursor()
    mycursor.execute("use Pharmacy;")
    mycursor.execute("Select sum(Price),Category from list_meds group by Category order by Category;")
    for data in mycursor:
        p=int(data[0])
        l1.append(p)
        q=str(data[1])
        l2.append(q)
    sale=pd.read_csv("C:/Users/student.JPHS/Desktop/Project folder/sales.csv")
    sale1=pd.DataFrame({'Category':l2,'Total Price':l1})
    import matplotlib.pyplot as plt
    sale.plot(kind='bar',x='YEAR',color=['purple','orange','green'])
    plt.xlabel('Year')
    plt.ylabel('Number of Medicine units sold')
    plt.title('SALES REPORT')
    plt.legend()
    plt.savefig('fig1.png')
    plt.show()

    sale1.plot(kind='bar',x='Category',color='pink',hatch='*')
    plt.xlabel('Category')
    plt.ylabel('Total Price of medicines in each')
    plt.title('Category wise ananlysis of cost')
    plt.savefig('fig2.png')
    plt.show()
 

def runagain():
    run=input("Do you want to run again(y/n)?:")
    while run.lower()=='y':
        Menu()
        run=input("Do you want to run again(y/n)?:")
        print('')
    quit()

Menu()
runagain()
    
    
    
    

